#!/usr/bin/env bash
echo "run_benchmark for floorplan0 using openroad/floorplan"
echo "see README.txt for more information"
echo "executing in build/run_benchmark/job0/floorplan/0"
cd build/run_benchmark/job0/floorplan/0
./replay.sh