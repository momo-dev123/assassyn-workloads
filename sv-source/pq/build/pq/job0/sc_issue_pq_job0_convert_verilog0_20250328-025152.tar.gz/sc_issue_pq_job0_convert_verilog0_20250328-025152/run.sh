#!/usr/bin/env bash
echo "pq for convert_verilog0 using sv2v/convert"
echo "see README.txt for more information"
echo "executing in build/pq/job0/convert_verilog/0"
cd build/pq/job0/convert_verilog/0
./replay.sh