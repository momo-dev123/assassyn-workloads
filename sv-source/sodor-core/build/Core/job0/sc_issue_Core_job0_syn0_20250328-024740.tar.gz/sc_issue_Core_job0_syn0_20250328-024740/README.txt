SiliconCompiler test case

To run this testcase:
./run.sh
-- or --
sc-issue -run -file sc_issue_Core_job0_syn0_20250328-024740.tar.gz

** SiliconCompiler information **
Version: 0.28.4
Schema: 0.48.2

** Run **
Testcase built: 2025-03-28 02:47:40
Tool: yosys 0.43
Task: syn_asic
Node: syn0

** Python **
Version: 3.10.12 (main, Sep 11 2024, 15:47:36) [GCC 11.4.0]

** Machine **
System: linux
Distribution: ubuntu
Version: 22.04
Kernel version: 5.15.0-94-generic
Architecture: x86_64