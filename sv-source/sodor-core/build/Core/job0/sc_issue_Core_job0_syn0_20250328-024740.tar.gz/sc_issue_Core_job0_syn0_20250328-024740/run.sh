#!/usr/bin/env bash
echo "Core for syn0 using yosys/syn_asic"
echo "see README.txt for more information"
echo "executing in build/Core/job0/syn/0"
cd build/Core/job0/syn/0
./replay.sh