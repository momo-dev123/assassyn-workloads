SiliconCompiler test case

To run this testcase:
./run.sh
-- or --
sc-issue -run -file sc_issue_top_job0_floorplan0_20250328-021337.tar.gz

** SiliconCompiler information **
Version: 0.28.4
Schema: 0.48.2

** Run **
Testcase built: 2025-03-28 02:13:37
Tool: openroad v2.0-16697
Task: floorplan
Node: floorplan0

** Python **
Version: 3.10.12 (main, Sep 11 2024, 15:47:36) [GCC 11.4.0]

** Machine **
System: linux
Distribution: ubuntu
Version: 22.04
Kernel version: 5.15.0-94-generic
Architecture: x86_64