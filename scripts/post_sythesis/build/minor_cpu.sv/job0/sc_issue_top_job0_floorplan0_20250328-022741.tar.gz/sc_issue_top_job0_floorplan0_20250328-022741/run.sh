#!/usr/bin/env bash
echo "top for floorplan0 using openroad/floorplan"
echo "see README.txt for more information"
echo "executing in build/top/job0/floorplan/0"
cd build/top/job0/floorplan/0
./replay.sh